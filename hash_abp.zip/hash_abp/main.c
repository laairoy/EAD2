#include "hash.h"
#include <stdio.h>


int main()
{
	HASH * hash = init_hash(1000);

	inserir_hash(hash, 1);
	inserir_hash(hash, 1001);
	ABP * abp = buscar_hash(hash, 1001);
	printf("elemento %d encontrado\n", abp->chave);
	return 0;
}